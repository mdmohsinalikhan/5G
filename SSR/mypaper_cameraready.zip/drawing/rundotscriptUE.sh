dot -Teps UE_diagram.gv -o UE_diagram.eps
