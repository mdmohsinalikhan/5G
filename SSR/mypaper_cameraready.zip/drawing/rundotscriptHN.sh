dot -Teps HN_diagram.gv -o HN_diagram.eps
