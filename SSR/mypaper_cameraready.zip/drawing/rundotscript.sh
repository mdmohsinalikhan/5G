dot -Gratio=auto -Tpng -o HN_diagram.png HN_diagram.dot
xdg-open HN_diagram.png
